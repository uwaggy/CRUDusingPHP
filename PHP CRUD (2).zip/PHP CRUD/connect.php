<?php
$dbHost = "localhost";
$dbUser = "root";
$dbPassword  = "";
$dbName = "crud";
$conn = mysqli_connect($dbHost,$dbUser,$dbPassword,$dbName );
if(!$conn){
    echo "Something went wrong";
}else{
    echo"connected successfully";
}

?>