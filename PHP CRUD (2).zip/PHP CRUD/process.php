<?php
include("connect.php");
if (isset($_POST['create'])){
$title =$_POST["title"];
$author =$_POST["author"];
$type =$_POST["type"];
$description =$_POST["description"];
$sql = "INSERT INTO books(title,author,type,description) VALUES ('$title','$author','$type','$description')";
if (mysqli_query($conn, $sql)){
   session_start();
   $_SESSION["create"] = "Book Added Successfully";
   header("Location:index.php");
}else{
    echo "Something went wrong";
}
}



?> 