<?php
include "connect.php";
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $sql = "DELETE FROM books WHERE id =$id";
    $result=$conn->query($sql);
    if($result){
    header("Location:index.php");
}else{
    echo 'Error:'.$sql.'<br>'.$conn->error;
}
$conn->close();
}
?>